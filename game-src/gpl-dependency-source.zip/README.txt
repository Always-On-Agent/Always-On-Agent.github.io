Exact installed GPL-declared dependency sources
Generated 2026-09-16 for Always-On Village browser prototype.

These are byte-for-byte files from the installed package distributions used by the fork, following package-directory symlinks and excluding nested node_modules, .git, caches and local environment files. No user credentials or private project files are included.

The upstream package metadata declares GPL-3.0. Some npm packages contain generated JavaScript without original TypeScript or a full upstream license file; this archive does not claim that a published npm distribution alone is a complete corresponding-source offering. Source repository links and exact package versions below identify where those additional materials originate. Keep the application source patch and build recipe alongside this archive.

@nxg-org/mineflayer-auto-jump@0.8.0
Declared license: GPL-3.0
Package metadata source: git+https://github.com/nxg-org/mineflayer-auto-jump.git
Included files: 10

@nxg-org/mineflayer-tracker@1.3.0
Declared license: GPL-3.0
Package metadata source: git+https://github.com/nxg-org/mineflayer-tracker.git
Included files: 47

@nxg-org/mineflayer-physics-util@1.9.10
Declared license: GPL-3.0
Package metadata source: git+https://github.com/nxg-org/mineflayer-physics-utils.git
Installed fork resolution: see pnpm-lock.yaml entry for zardoy/mineflayer-physics-utils. The actual installed files in this archive include that fork.
Included files: 78

@nxg-org/mineflayer-trajectories@1.2.0
Declared license: GPL-3.0
Package metadata source: git+https://github.com/nxg-org/mineflayer-trajectories.git
Included files: 20
