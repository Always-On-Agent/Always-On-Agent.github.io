import { Entity } from "prismarine-entity";
import { Bot } from "mineflayer";
import { Physics } from "../dist/physics/engines/physics";
import { ControlStateHandler } from "../dist/physics/player/playerControls";
import { EntityState } from "../dist/physics/states/entityState";
import { Vec3 } from "vec3";
export interface MovementSimOptions {
    sprintFirst: boolean;
    jumpFirst: boolean;
}
/**
 * To be used once per movement.
 *
 * Provide state that will serve as a base. The state itself will not be modified/consumed unless called for.
 */
export declare class MovementSimulations {
    bot: Bot;
    readonly ctx: Physics;
    constructor(bot: Bot, ctx: Physics);
    predictGenerator(state: EntityState, world: any, ticks?: number, controls?: ControlStateHandler): Generator<EntityState, EntityState, unknown>;
    predictForward(target: Entity, world: any, ticks?: number, controls?: ControlStateHandler): any;
    findCorrectMovements(lastState: EntityState, world: any, wantedPos: Vec3): ControlStateHandler;
}
