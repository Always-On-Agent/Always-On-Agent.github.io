import { Entity } from "prismarine-entity";
import { Bot } from "mineflayer";
import { Vec3 } from "vec3";
type TrackingInfo = {
    position: Vec3;
    velocity: Vec3;
    age: number;
};
export type TrackingData = {
    [entityId: number]: {
        tracking: boolean;
        info: {
            initialAge: number;
            avgVel: Vec3;
            tickInfo: TrackingInfo[];
        };
    };
};
export declare class EntityTracker {
    private bot;
    trackingData: TrackingData;
    private _enabled;
    private _tickAge;
    get enabled(): boolean;
    set enabled(value: boolean);
    constructor(bot: Bot);
    private hawkeyeRewriteTracking;
    trackEntity(entity: Entity): void;
    stopTrackingEntity(entity: Entity, clear?: boolean): void;
    getEntitySpeed(entity: Entity): Vec3 | null;
    getEntityPositionInfo(entity: Entity): {
        position: Vec3;
        velocity: Vec3;
    }[];
    clearTrackingData(): void;
    update(): void;
    enable(): void;
    disable(): void;
}
export {};
