import { EntityTracker } from "./entityTracker";
import { ProjectileTracker } from "./projectileTracker";
import { Bot } from "mineflayer";
import { MovementSimulations } from "./dist/sims/nextSim";
declare module "mineflayer" {
    interface Bot {
        tracker: EntityTracker;
        projectiles: ProjectileTracker;
    }
}
export default function plugin(bot: Bot): void;
export { EntityTracker };
export { ProjectileTracker };
export { MovementSimulations };
