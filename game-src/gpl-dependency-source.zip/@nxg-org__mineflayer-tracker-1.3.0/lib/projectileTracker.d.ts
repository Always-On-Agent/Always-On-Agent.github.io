import { Bot } from "mineflayer";
import { BasicShotInfo } from "@nxg-org/mineflayer-trajectories";
import type { Entity } from "prismarine-entity";
import type { Block } from "prismarine-block";
import type { Vec3 } from "vec3";
type InfoBoundToEntity = {
    entity: Entity;
    shotInfo: BasicShotInfo;
};
export declare class ProjectileTracker {
    private bot;
    private intercepter;
    private projectilesChecked;
    private entitiesChecked;
    private $isAimedAt;
    private $projectileAtMe;
    detectIncomingProjectiles: boolean;
    detectAimingEntities: boolean;
    constructor(bot: Bot);
    get isAimedAt(): InfoBoundToEntity | null;
    get projectileAtMe(): InfoBoundToEntity | null;
    perTickHandler: () => Promise<void>;
    getIncomingArrow(): InfoBoundToEntity | null;
    getIncomingArrows(): InfoBoundToEntity[];
    getIncomingProjectiles(): InfoBoundToEntity[];
    getHighestPriorityProjectile(doesDamage?: boolean): InfoBoundToEntity | null;
    allProjectileInfo(): {
        entity: Entity;
        info: {
            block: Block | null;
            hitPos: Vec3 | null;
            totalTicks: number;
        };
    }[];
    getMobsAimingAtBot(): InfoBoundToEntity[];
    getPlayersAimingAtBot(): InfoBoundToEntity[];
    getAimingEntities(): InfoBoundToEntity[];
    getHighestPriorityEntity(): InfoBoundToEntity | null;
    getShotDestination(entity: Entity): InfoBoundToEntity[] | null;
    getProjectileDestination(entity: Entity): InfoBoundToEntity[] | null;
}
export {};
