import { AABB } from "@nxg-org/mineflayer-util-plugin";
import { CheapEffects, CheapEnchantments, isEntityUsingItem, isUsableElytraItem, whichHandIsEntityUsingBoolean } from "../../util/physicsUtils";
import type { Bot, Effect } from "mineflayer";
import { Vec3 } from "vec3";


import { ControlStateHandler } from "../player/playerControls";
import type { PlayerState } from "./playerState";
import { PlayerPoses } from "./poses";

import type { IPhysics } from "../engines";
import nbt from "prismarine-nbt";
import {Entity} from "prismarine-entity";
import type { IEntityState } from ".";




const emptyVec = new Vec3(0, 0, 0);
export class EntityState implements IEntityState {
    // may keep this, may not. Who knows?
    public age: number = 0;
    public isInWater: boolean;
    public isInLava: boolean;
    public isInWeb: boolean;
    public fallFlying: boolean;
    public validElytraEquipped: boolean;
    public isCollidedHorizontally: boolean;
    public isCollidedVertically: boolean;
    public jumpTicks: number;
    public jumpQueued: boolean;

    public onClimbable: boolean = false;

    public sneakCollision: boolean;

    public attributes: Entity["attributes"] /* dunno yet */;

    public isUsingItem: boolean;
    public isUsingMainHand: boolean;
    public isUsingOffHand: boolean;

    public jumpBoost: number;
    public speed: number;
    public slowness: number;
    public dolphinsGrace: number;
    public slowFalling: number;
    public levitation: number;
    public depthStrider: number;

    public effects: Effect[];
    public pose: PlayerPoses;
    public fireworkRocketDuration: number;

    public supportingBlockPos: Vec3 | null;

    /**
     * Deprecated compatibility alias for fallFlying.
     */
    public get elytraFlying(): boolean {
        return this.fallFlying;
    }

    public set elytraFlying(value: boolean) {
        this.fallFlying = value;
    }

    // public effects: Effect[];
    // public statusEffectNames;

    constructor(
        public ctx: IPhysics,
        public height: number,
        public halfWidth: number,
        public pos: Vec3,
        public vel: Vec3,
        public onGround: boolean,
        public yaw: number,
        public pitch: number,
        public control: ControlStateHandler = ControlStateHandler.DEFAULT()
    ) {
        this.isInWater = false;
        this.isInLava = false;
        this.isInWeb = false;
        this.fallFlying = false;
        this.validElytraEquipped = false;
        this.isCollidedHorizontally = false;
        this.isCollidedVertically = false;
        this.sneakCollision = false; //TODO

        //not sure what to do here, ngl.
        this.jumpTicks = 0;
        this.jumpQueued = false;
        this.fireworkRocketDuration = 0;

        // Input only (not modified)
        this.attributes = {}; //TODO

        this.isUsingItem = false;
        this.isUsingMainHand = false;
        this.isUsingOffHand = false;

        // effects
        this.effects = [];

        this.jumpBoost = 0;
        this.speed = 0;
        this.slowness = 0;

        this.dolphinsGrace = 0;
        this.slowFalling = 0;
        this.levitation = 0;

        this.depthStrider = 0;

        this.pose = PlayerPoses.STANDING;
        this.supportingBlockPos = null;
    }

    public static CREATE_FROM_BOT(ctx: IPhysics, bot: Bot): EntityState {
        return new EntityState(
            ctx,
            bot.entity.height,
            bot.entity.width / 2,
            bot.entity.position.clone(),
            bot.entity.velocity.clone(),
            bot.entity.onGround,
            bot.entity.yaw,
            bot.entity.pitch,
            ControlStateHandler.COPY_BOT(bot)
        ).updateFromBot(bot);
    }

    public static CREATE_FROM_ENTITY(ctx: IPhysics, entity: Entity): EntityState {
        return new EntityState(
            ctx,
            entity.height,
            entity.width / 2,
            entity.position.clone(),
            entity.velocity.clone(),
            entity.onGround,
            entity.yaw,
            entity.pitch,
            ControlStateHandler.DEFAULT()
        ).updateFromEntity(entity);
    }

    public static CREATE_FROM_PLAYER_STATE(ctx: IPhysics, state: PlayerState): EntityState {
        return new EntityState(
            ctx,
            state.height,
            state.halfWidth,
            state.pos.clone(),
            state.vel.clone(),
            state.onGround,
            state.yaw,
            state.pitch,
            state.control.clone()
        ).updateFromRaw(state);
    }

    /**
     * Slightly different from the other two, use a pre-built object (assuming cloned) material.
     * @param ctx Physics instance.
     * @param raw CONSUMEABLE, build this with clones.
     * @returns PhysicsState
     */
    public static CREATE_RAW(ctx: IPhysics, raw: IEntityState) {
        return new EntityState(ctx, raw.height, raw.halfWidth, raw.pos, raw.vel, raw.onGround, raw.yaw, raw.pitch, raw.control);
    }

    public updateFromBot(bot: Bot): EntityState {
        this.updateFromEntity(bot.entity, true);
        this.control = ControlStateHandler.COPY_BOT(bot);
        this.jumpTicks = (bot as any).jumpTicks;
        this.jumpQueued = (bot as any).jumpQueued;
        this.fireworkRocketDuration = bot.fireworkRocketDuration
        return this;
    }

    public updateFromEntity(entity: Entity, all: boolean = false) {

        if (all) {
            // most mobs don't have this defined, so ignore it (only self does).
            this.vel.set(entity.velocity.x, entity.velocity.y, entity.velocity.z);
            this.onGround = entity.onGround;
            this.onClimbable = (entity as any).onClimbable;
            this.isInWater = (entity as any).isInWater;
            this.isInLava = (entity as any).isInLava;
            this.isInWeb = (entity as any).isInWeb;
            this.fallFlying = (entity as any).fallFlying ?? (entity as any).elytraFlying ?? false;
            this.isCollidedHorizontally = (entity as any).isCollidedHorizontally;
            this.isCollidedVertically = (entity as any).isCollidedVertically;
            this.sneakCollision = false; //TODO
            this.attributes ||= entity.attributes;

            this.validElytraEquipped = isUsableElytraItem(entity.equipment[4]);
            this.fallFlying = this.validElytraEquipped && this.fallFlying
        }
        this.pos.set(entity.position.x, entity.position.y, entity.position.z);


        //not sure what to do here, ngl.
        this.jumpTicks ||= 0;
        this.jumpQueued ||= false;

        // Input only (not modified)
        this.yaw = entity.yaw;
        this.pitch = entity.pitch;
        this.control ||= ControlStateHandler.DEFAULT();

        this.isUsingItem = isEntityUsingItem(entity, this.ctx.supportFeature);
        this.isUsingMainHand = !whichHandIsEntityUsingBoolean(entity, this.ctx.supportFeature) && this.isUsingItem;
        this.isUsingOffHand = whichHandIsEntityUsingBoolean(entity, this.ctx.supportFeature) && this.isUsingItem;

        // effects
        this.effects = entity.effects;

        this.jumpBoost = this.ctx.getEffectLevel(CheapEffects.JUMP_BOOST, this.effects);
        this.speed = this.ctx.getEffectLevel(CheapEffects.SPEED, this.effects);
        this.slowness = this.ctx.getEffectLevel(CheapEffects.SLOWNESS, this.effects);

        this.dolphinsGrace = this.ctx.getEffectLevel(CheapEffects.DOLPHINS_GRACE, this.effects);
        this.slowFalling = this.ctx.getEffectLevel(CheapEffects.SLOW_FALLING, this.effects);
        this.levitation = this.ctx.getEffectLevel(CheapEffects.LEVITATION, this.effects);

        // armour enchantments
        //const boots = bot.inventory.slots[8];
        const boots = entity.equipment[5];
        if (boots && boots.nbt) {
            const simplifiedNbt = nbt.simplify(boots.nbt);
            const enchantments = simplifiedNbt.Enchantments ?? simplifiedNbt.ench ?? [];
            this.depthStrider = this.ctx.getEnchantmentLevel(CheapEnchantments.DEPTH_STRIDER, enchantments);
        } else {
            this.depthStrider = 0;
        }

        this.pose ||= PlayerPoses.STANDING;
        return this;
    }

    public updateFromRaw(other: IEntityState) {
        this.onGround = other.onGround ?? this.onGround;
        this.onClimbable = other.onClimbable ?? this.onClimbable;
        this.sneakCollision = other.sneakCollision ?? this.sneakCollision;
        this.isUsingItem = other.isUsingItem ?? this.isUsingItem;
        this.jumpBoost = other.jumpBoost ?? this.jumpBoost;
        this.speed = other.speed ?? this.speed;
        this.slowness = other.slowness ?? this.slowness;
        this.dolphinsGrace = other.dolphinsGrace ?? this.dolphinsGrace;
        this.slowFalling = other.slowFalling ?? this.slowFalling;
        this.levitation = other.levitation ?? this.levitation;
        this.depthStrider = other.depthStrider ?? this.depthStrider;
        this.effects = other.effects ?? this.effects;
        this.isCollidedHorizontally = other.isCollidedHorizontally ?? this.isCollidedHorizontally;
        this.isCollidedVertically = other.isCollidedVertically ?? this.isCollidedVertically;
        this.isInWater = other.isInWater ?? this.isInWater;
        this.isInLava = other.isInLava ?? this.isInLava;
        this.isInWeb = other.isInWeb ?? this.isInWeb;
        this.fallFlying = other.fallFlying ?? other.elytraFlying ?? this.fallFlying;
        this.validElytraEquipped = other.validElytraEquipped ?? this.validElytraEquipped;
        return this;
    }

    public applyToBot(bot: Bot) {
        bot.entity.position.set(this.pos.x, this.pos.y, this.pos.z);
        bot.entity.velocity.set(this.vel.x, this.vel.y, this.vel.z);
        bot.entity.onGround = this.onGround;
        (bot.entity as any).onClimbable = this.onClimbable;
        bot.entity.yaw = this.yaw;
        bot.entity.pitch = this.pitch;
        bot.entity.height = this.height;
        bot.entity.width = this.halfWidth * 2;
        bot.controlState = this.control;
        (bot as any).jumpTicks = this.jumpTicks;
        (bot as any).jumpQueued = this.jumpQueued;
        bot.fireworkRocketDuration = this.fireworkRocketDuration;
        (bot.entity as any).isInWater = this.isInWater;
        (bot.entity as any).isInLava = this.isInLava;
        (bot.entity as any).isInWeb = this.isInWeb;
        (bot.entity as any).fallFlying = this.fallFlying;
        bot.entity.elytraFlying = this.fallFlying;
        (bot.entity as any).elytraEquipped = this.validElytraEquipped;
        (bot.entity as any).isCollidedHorizontally = this.isCollidedHorizontally;
        (bot.entity as any).isCollidedVertically = this.isCollidedVertically;
        (bot.entity as any).sneakCollision = this.sneakCollision;
        (bot.entity as any).pose = this.pose;
        this.control.applyControls(bot);

        return this;
    }

    /**
     * No idea when you'd use this.
     */
    public applyToEntity(entity: Entity) {
        entity.position.set(this.pos.x, this.pos.y, this.pos.z)
        entity.velocity.set(this.vel.x, this.vel.y, this.vel.z)
        // entity.position.set(this.position.x, this.position.y, this.position.z);
        // entity.velocity.set(this.velocity.x, this.velocity.y, this.velocity.z);
        entity.onGround = this.onGround;
        (entity as any).onClimbable = this.onClimbable;
        entity.yaw = this.yaw;
        entity.pitch = this.pitch;
        return this;
    }

    public clone(): EntityState {
        const other = new EntityState(
            this.ctx,
            this.height,
            this.halfWidth,
            this.pos.clone(),
            this.vel.clone(),
            this.onGround,
            this.yaw,
            this.pitch,
            this.control.clone(),
        );
        other.onClimbable = this.onClimbable;
        other.age = this.age;
        other.isCollidedHorizontally = this.isCollidedHorizontally;
        other.isCollidedVertically = this.isCollidedVertically;
        other.isInWater = this.isInWater;
        other.isInLava = this.isInLava;
        other.isInWeb = this.isInWeb;
        other.fallFlying = this.fallFlying;
        other.validElytraEquipped = this.validElytraEquipped;
        other.fireworkRocketDuration = this.fireworkRocketDuration;
        other.jumpTicks = this.jumpTicks;
        other.jumpQueued = this.jumpQueued;
        other.sneakCollision = this.sneakCollision;
        other.attributes = this.attributes;
        other.isUsingItem = this.isUsingItem;
        other.isUsingMainHand = this.isUsingMainHand;
        other.isUsingOffHand = this.isUsingOffHand;
        other.jumpBoost = this.jumpBoost;
        other.speed = this.speed;
        other.slowness = this.slowness;
        other.dolphinsGrace = this.dolphinsGrace;
        other.slowFalling = this.slowFalling;
        other.levitation = this.levitation;
        other.depthStrider = this.depthStrider;
        other.effects = this.effects;
        other.pose = this.pose;
        return other;
    }

    public merge(other: EntityState) {
        this.age = other.age
        this.pos.set(other.pos.x, other.pos.y, other.pos.z)
        this.vel.set(other.vel.x, other.vel.y, other.vel.z)
        this.onGround = other.onGround;
        this.onClimbable = other.onClimbable;
        this.isCollidedHorizontally = other.isCollidedHorizontally;
        this.isCollidedVertically = other.isCollidedVertically;
        this.isInWater = other.isInWater;
        this.isInLava = other.isInLava;
        this.isInWeb = other.isInWeb;
        this.fallFlying = other.fallFlying;
        this.validElytraEquipped = other.validElytraEquipped;
        this.fireworkRocketDuration = other.fireworkRocketDuration;
        this.jumpTicks = other.jumpTicks;
        this.jumpQueued = other.jumpQueued;
        this.sneakCollision = other.sneakCollision;
        this.attributes = other.attributes;
        this.isUsingItem = other.isUsingItem;
        this.isUsingMainHand = other.isUsingMainHand;
        this.isUsingOffHand = other.isUsingOffHand;
        this.jumpBoost = other.jumpBoost;
        this.speed = other.speed;
        this.slowness = other.slowness;
        this.dolphinsGrace = other.dolphinsGrace;
        this.slowFalling = other.slowFalling;
        this.levitation = other.levitation;
        this.depthStrider = other.depthStrider;
        this.effects = other.effects;
        this.pose = other.pose;
        return this;
    }

    public clearControlStates(): EntityState {
        this.control = ControlStateHandler.DEFAULT();
        return this;
    }

    /**
     * needs to be updated.
     * @returns AABB
     */
    public getBB(): AABB {
        const hW = this.halfWidth;
        return new AABB(
            this.pos.x - hW,
            this.pos.y,
            this.pos.z - hW,
            this.pos.x + hW,
            this.pos.y + this.height,
            this.pos.z + hW
        );
    }

    public lookAt(vec3: Vec3) {
        const dx = vec3.x - this.pos.x;
        const dy = vec3.y - this.pos.y;
        const dz = vec3.z - this.pos.z;

        this.yaw = Math.atan2(dz, dx) * 180 / Math.PI - 90;
        this.pitch = -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180 / Math.PI;
    }

    public look(yaw: number, pitch:number) {
        this.yaw = yaw;
        this.pitch = pitch;
    }
}
