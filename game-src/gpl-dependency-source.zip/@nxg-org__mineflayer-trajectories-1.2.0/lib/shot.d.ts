import { Vec3 } from "vec3";
import type { Bot } from "mineflayer";
import { Block } from "prismarine-block";
import type { Entity } from "prismarine-entity";
import { AABB, InterceptFunctions } from "@nxg-org/mineflayer-util-plugin";
import { AABBComponents, BasicShotInfo, BoundedShotInfo, ProjectileMotion } from "./types";
/**
 * TODO: Change hit detection from AABB -> Ray to AABB -> Moving AABB of 0.5h, 0.5w.
 * ! We are "missing" shots due to this miscalculation.
 * * DONE! WOOOOOOOOOO
 *
 * TODO: Completely rewrite arrow trajectory calculation. Currently using assumptions, can be much better.
 * ! It is very fast; I will have to optimize even more.
 * * DONE! WOOOOOOOOOO
 *
 * TODO: Work on caching arrow trajectories. This will speed up repeated look-ups and encourage reuse of classes to save RAM/CPU.
 *
 */
/**
 * uses:
 * (a) calculate shot based off current entities yaw and target
 * (b) calculate correct yaw and target
 * (c) better block detection
 * (d) velocity checks
 */
/**
 * Purposely left off prediction.
 * You can handle that outside of the Shot class.
 */
export declare class Shot {
    readonly initialPos: Vec3;
    readonly initialVel: Vec3;
    readonly initialYaw: number;
    readonly initialPitch: number;
    readonly gravity: number;
    readonly airResistance: number;
    private points;
    private pointVelocities;
    private blockHit;
    interceptCalcs?: InterceptFunctions;
    blockCheck: boolean;
    constructor(originVel: Vec3, { position: pPos, velocity: pVel, gravity, airResistance }: Required<ProjectileMotion>, interceptCalcs?: InterceptFunctions);
    canCollisionDetect(): boolean;
    loadWorld(bot: Bot): void;
    HitCheckXZ(entity: AABBComponents): boolean;
    entityXYZInterceptCheck({ position, height, width }: AABBComponents): Vec3 | null;
    entityXZInterceptCheck({ position, height, width }: AABBComponents): {
        x: number;
        z: number;
    } | null;
    hitEntitiesCheckXZ(...entities: Entity[]): Entity[];
    private aabbHitCheckXZ;
    hitEntitiesCheck(blockCheck?: boolean, ...entities: AABBComponents[]): {
        entity: AABB;
        shotInfo: BasicShotInfo;
    }[];
    hitsEntity(entity: AABBComponents, extras?: {
        yawChecked: boolean;
        blockCheck: boolean;
    }): BoundedShotInfo | null;
    hitsEntities(blockCheck?: boolean, ...entities: AABBComponents[]): BoundedShotInfo[];
    hitsEntityWithPrediction({ position, height, width }: AABBComponents, avgSpeed: Vec3): BasicShotInfo;
    /**
     *
     * @param {boolean} blockChecking Whether to check for blocks or not.
     * @param {Entity[]} Entity list of entities from Prismarine-entity.
     * @returns TODO: Typing
     */
    calcToIntercept(blockChecking?: boolean, entities?: Entity[]): {
        block: Block | null;
        hitPos: Vec3 | null;
        totalTicks: number;
    };
    calcToEntity(target: AABBComponents | AABB, blockChecking?: boolean): BasicShotInfo;
}
