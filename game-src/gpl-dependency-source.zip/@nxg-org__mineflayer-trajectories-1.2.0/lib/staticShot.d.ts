import { InterceptFunctions } from "@nxg-org/mineflayer-util-plugin";
import { Block } from "prismarine-block";
import { Vec3 } from "vec3";
import { AABBComponents, BaseProjectileObjInfo } from "./types";
export declare class StaticShot {
    static checkForEntityHitFromSortedPoints({ position, height, width }: AABBComponents, points: Vec3[], notchianPointVecs: Vec3[], blockChecker?: InterceptFunctions, blockChecking?: boolean): {
        closestPoint: Vec3;
        blockHit: Block | null;
    };
    static calculateShotForCollision({ position, velocity, name }: BaseProjectileObjInfo, target: AABBComponents, blockChecking?: boolean, blockChecker?: InterceptFunctions): {
        positions: Vec3[];
        velocities: Vec3[];
        blockHit: Block | null;
        intersectPos: Vec3 | null;
    };
    static calculateShotForPoints({ position, velocity, name }: BaseProjectileObjInfo, blockChecking?: boolean, blockChecker?: InterceptFunctions): {
        positions: Vec3[];
        velocities: Vec3[];
        blockHit: Block | null;
    };
}
