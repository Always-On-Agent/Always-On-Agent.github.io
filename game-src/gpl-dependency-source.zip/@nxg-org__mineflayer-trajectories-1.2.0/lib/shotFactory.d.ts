import { InterceptFunctions } from "@nxg-org/mineflayer-util-plugin";
import { Shot } from "./shot";
import { ShotEntity, BaseProjectileObjInfo } from "./types";
export declare class ShotFactory {
    static fromPlayer: typeof ShotFactory.fromShootingPlayer;
    static fromShootingPlayer({ position, yaw, pitch, velocity, heldItem, onGround }: ShotEntity, interceptCalcs?: InterceptFunctions, weapon?: string): Shot;
    static fromMob({ position, velocity, yaw, pitch, onGround, name }: ShotEntity, interceptCalcs?: InterceptFunctions): Shot;
    static fromEntity({ position, velocity, name }: BaseProjectileObjInfo, interceptCalcs?: InterceptFunctions): Shot;
}
