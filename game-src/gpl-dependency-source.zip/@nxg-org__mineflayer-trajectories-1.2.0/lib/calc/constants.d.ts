import { ProjectileEnvInfo } from "../types";
type ProjectileInfos = {
    [name: string]: ProjectileEnvInfo;
};
export declare const projectileGravity: Record<string, number>;
export declare const projectileAirResistance: Record<string, number>;
export declare const trajectoryInfo: ProjectileInfos;
export declare enum BlockFace {
    UNKNOWN = -999,
    BOTTOM = 0,
    TOP = 1,
    NORTH = 2,
    SOUTH = 3,
    WEST = 4,
    EAST = 5
}
export {};
